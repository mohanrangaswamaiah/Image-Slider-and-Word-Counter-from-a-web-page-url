﻿
using System;
using System.IO;
using System.Linq;
using System.Net;
using System.Windows.Forms;

namespace WindowsFormsWebDataReader
{
    public partial class ImageSlider : Form
    {
        public ImageSlider(string url)
        {
            InitializeComponent();
            
            GetWebpage(url);
        }

        //Images folder is created within the VS Solution
        public static string folderPath = System.IO.Directory.GetCurrentDirectory()?.Replace("\\bin\\Debug", "\\Images\\");
        private void GetWebpage(string url)
        {
            DeleteImages();
            WebBrowser browser = new WebBrowser();
            browser.ScriptErrorsSuppressed = true;
            browser.Navigate(url);
            browser.DocumentCompleted += new WebBrowserDocumentCompletedEventHandler(browser_DocumentCompleted);
        }
        
        //Delete older images if there is any from Images folder 
        void DeleteImages()
        {
            DirectoryInfo folderDir = new DirectoryInfo(folderPath);
            FileInfo[] files = folderDir.GetFiles();
            foreach (FileInfo file in files)
            {
                file.Delete();
            }
        }
        
        //Document Completed event
        void browser_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {
            var browser = (WebBrowser)sender;
            var client = new WebClient();
            int i = 0;

            foreach (var img in browser.Document.Images)
            {
                var image = img as HtmlElement;
                var src = image.GetAttribute("src").TrimEnd('/');
                if (!Uri.IsWellFormedUriString(src, UriKind.Absolute))
                {
                    src = string.Concat(browser.Document.Url.AbsoluteUri, "/", src);
                }
               
                var filename = new string(src.Skip(src.LastIndexOf('/') + 1).ToArray());

                //Download the images into Images folder within the VS Solution
                filename = folderPath + "photo"+i+".jpg";
                File.WriteAllBytes(filename, client.DownloadData(src));
                i++;
            }
        }

        //Time ticker to move images slider
        int i = 0;
        private void timer1_Tick(object sender, EventArgs e)
        {
            string[] images = Directory.GetFiles(@"../../Images", "*.jpg");
            
            if(images.Count() > i)
            {
                pictureBox1.ImageLocation = string.Format(images[i]);
            }

            i++;
        }
    }
}
