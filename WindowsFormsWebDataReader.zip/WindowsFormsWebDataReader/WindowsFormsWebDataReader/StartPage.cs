﻿using System;
using System.Windows.Forms;

namespace WindowsFormsWebDataReader
{
    public partial class StartPage : Form
    {
        public StartPage()
        {
            InitializeComponent();
        }
        public static string SetValueForText1 = "";
        public static string SetValueForText2 = "";

        //First button click will call the Image Slider form
        private void button1_Click(object sender, EventArgs e)
        {
            ImageSlider imageSlider = new ImageSlider(textBox1?.Text);
            imageSlider.Show();
        }

        //Second button click will call the Word  Counter form
        private void button2_Click(object sender, EventArgs e)
        {
            WordCounter wordCounter = new WordCounter(textBox2?.Text);
            wordCounter.Show();
        }

    }
}
