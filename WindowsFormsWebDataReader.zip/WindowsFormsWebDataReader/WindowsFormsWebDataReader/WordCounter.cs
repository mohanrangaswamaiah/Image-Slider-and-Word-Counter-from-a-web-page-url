﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;
using System.Web.UI.HtmlControls;
using System.Windows.Forms;

namespace WindowsFormsWebDataReader
{
    public partial class WordCounter : Form
    {
        /// <summary>
        /// Pass the url of site you want count the word for
        /// </summary>
        /// <param name="url"></param>
        public WordCounter(string url)
        {
            InitializeComponent();
            Uri = new Uri(url);
        }

        private static Uri Uri { get; set; }
        private void Form2_Load(object sender, EventArgs e)
        {
            this.dataGridView1.DataSource = GetWordsCount();
            this.dataGridView1.AllowUserToAddRows = false;
        }
        
        //Get the words count in a Data Table format
        private DataTable GetWordsCount()
        {
            WebClient client = new WebClient();
            client.Encoding = System.Text.Encoding.UTF8;
            
            //Download html string
            string html = client.DownloadString(Uri);

            HtmlAgilityPack.HtmlDocument doc = new HtmlAgilityPack.HtmlDocument();
            doc.LoadHtml(html);

            char[] delimiter = new char[] { ' ' };
            int kelime = 0;
            IList<string> allWords = new List<string>();

            //Select the words from Html Document. Omit the script tags
            foreach (string text in doc.DocumentNode
                .SelectNodes("//body//text()[not(parent::script)]")
                .Select(node => node.InnerText))
            {
                var words = text.Split(delimiter, StringSplitOptions.RemoveEmptyEntries)
                    .Where(s => Char.IsLetter(s[0]));
                
                int wordCount = words.Count();
                if (wordCount > 0)
                {
                    kelime += wordCount;
                }
                foreach(var word in words)
                {
                    allWords.Add(word);
                }
            }
            return FrequentWord(allWords);
        }

        // Function to calculate the 10 most frequent words in the dictionary
        public static DataTable FrequentWord(IList<string> allWords)
        {
            // Insert all unique strings and update count if a string is not unique.
            IDictionary<String, int> dictionary = new Dictionary<String, int>();
            foreach (var word in allWords)
            {
                if (dictionary.ContainsKey(word)) // if already exists then update count. 
                    dictionary[word] = dictionary[word] + 1;
                else
                    dictionary.Add(word, 1); // else insert it in the dictionary.
            }

            //Order the dictionary items in Descending order based on the value
            var ordered = dictionary.OrderByDescending(x => x.Value).ToDictionary(x => x.Key, x => x.Value);

            int i = 0;
            // Create a DataTable with necessary columns
            DataTable table = new DataTable();
            table.Columns.AddRange(new DataColumn[3] { new DataColumn("Total Words", typeof(string)),
                        new DataColumn("Word", typeof(string)),
                        new DataColumn("Count",typeof(string)) });
            table.Rows.Add("Total Words: ", "", allWords?.Count);

            //add the dictionary items which was sorted in descending order
            foreach (var item in ordered)
            {
                table.Rows.Add("", item.Key, item.Value);
                
                //Break the loop after 10 iterations
                i++;
                if (i == 10)
                    break;
            }
            return table;
        }

    }
}
